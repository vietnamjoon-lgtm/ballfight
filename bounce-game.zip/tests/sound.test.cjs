const fs = require('node:fs'), vm = require('node:vm'), path = require('node:path'), assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
let played = 0;
class AudioMock {
  constructor() { this.state = 'running'; this.currentTime = 0; this.destination = {}; this.sampleRate = 8000; }
  createOscillator() { return { frequency: { setValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {}, disconnect() {}, start() { played++; }, stop() {} }; }
  createGain() { return { gain: { setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {}, disconnect() {} }; }
  createBuffer(channels, length) { return { getChannelData: () => new Float32Array(length) }; }
  createBufferSource() { return { connect() {}, disconnect() {}, start() {}, stop() {} }; }
  createBiquadFilter() { return { frequency: { setValueAtTime() {} }, connect() {}, disconnect() {} }; }
}
const scope = vm.createContext({ AudioContext: AudioMock });
for (const name of ['abilities.js', 'characters.js', 'engine.js', 'sound.js']) vm.runInContext(fs.readFileSync(path.join(root, name), 'utf8'), scope);
const { Battle, PAD } = scope.ArenaEngine;
const battle = new Battle(scope.ArenaDefaults, ['blue', 'coral']);
const f = battle.fighters[0];
f.x = f.y = PAD + f.radius; f.vx = f.vy = -185; battle.wall(f);
assert.equal(battle.wallHits.length, 1, '모서리는 한 번만 발음');
battle.wallHits = []; battle.wall(f); assert.equal(battle.wallHits.length, 0, '안쪽으로 이동 중인 경계 접촉은 무음');
battle.wall({ x: PAD, y: 200, vx: -100, vy: 0, radius: 5 }); assert.equal(battle.wallHits.length, 0, '탄환은 무음');
battle.damage(f, 10); assert.equal(battle.wallHits.length, 0, '피격은 무음');
battle.wallHits.push({ slot: 0 }); battle.pause(); battle.step(1 / 120); assert.equal(battle.wallHits.length, 0, '정지 중 이벤트 잔여 없음');
const sound = new scope.ArenaWallSound(); sound.hit(0); assert.equal(played, 0, '시작 전 무음');
sound.unlock(); sound.hit(0); assert.equal(played, 1);
sound.hit(0); assert.equal(played, 1, '중복 연속 충돌 제한');
sound.hit(1); assert.equal(played, 2, '서로 다른 두 캐릭터는 각각 발음');
sound.context.currentTime = .1; sound.enabled = false; sound.hit(0); assert.equal(played, 2, '음소거');
sound.enabled = true; sound.context.state = 'suspended'; sound.hit(0); assert.equal(played, 2, '중단된 오디오는 큐에 쌓지 않음');
sound.context.state = 'running'; sound.hit(0); assert.equal(played, 3);
sound.play('missileLaunch'); assert.equal(played,5);
sound.play('missileExplosion'); assert.equal(played,6);
sound.play('missileCharge'); assert.equal(played,7);
sound.enabled=false; sound.play('missileLaunch'); sound.play('missileExplosion'); assert.equal(played,7);
sound.play('missileCharge'); assert.equal(played,7);
sound.enabled=true; sound.play('unknown'); assert.equal(played,7);
sound.setFlight(true); const flight=sound.flight; assert.ok(flight); assert.equal(played,8);
sound.setFlight(true); assert.equal(sound.flight,flight); assert.equal(played,8,'반복 프레임에서 비행음 중첩 금지');
sound.setFlight(false); assert.equal(sound.flight,null);
sound.setFlight(true); assert.ok(sound.flight); sound.enabled=false; sound.setFlight(true); assert.equal(sound.flight,null,'음소거에서 루프 정리');
sound.enabled=true;sound.context.state='suspended';sound.setFlight(true);assert.equal(sound.flight,null);
sound.context.state='running';sound.setFlight(true);assert.ok(sound.flight);sound.setFlight(false);assert.equal(sound.flight,null,'종료/정지에서 정리');
console.log('소리 검사 통과: 벽 전용 충돌 이벤트, 발사음·폭발음 합성, 음소거, 시작 전 무음과 재개. 실제 청취 검사는 아님.');
