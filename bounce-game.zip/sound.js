// Synthetic wall tap, missile launch and explosion. No background music.
(function (global) {
  'use strict';
  class ArenaWallSound {
    constructor() { this.enabled = true; this.context = null; this.last = [-Infinity, -Infinity]; this.flight = null; }
    setFlight(active) {
      const c = this.context;
      if (!active || !this.enabled || !c || c.state !== 'running') {
        if (this.flight) {
          const { source, tone, gain, filter } = this.flight; this.flight = null;
          source.stop(); tone.stop(); source.disconnect(); tone.disconnect(); gain.disconnect(); filter.disconnect();
        }
        return;
      }
      if (this.flight) return; // One quiet propulsion bed, even with several missiles.
      const buffer = c.createBuffer(1, c.sampleRate, c.sampleRate), samples = buffer.getChannelData(0);
      for (let i = 0; i < samples.length; i++) samples[i] = (Math.random() * 2 - 1) * .75;
      const source = c.createBufferSource(), tone = c.createOscillator(), filter = c.createBiquadFilter(), gain = c.createGain();
      source.buffer = buffer; source.loop = true;
      tone.type = 'sawtooth'; tone.frequency.setValueAtTime(160, c.currentTime);
      filter.type = 'bandpass'; filter.frequency.setValueAtTime(700, c.currentTime);
      gain.gain.setValueAtTime(0, c.currentTime); gain.gain.linearRampToValueAtTime(.07, c.currentTime + .08);
      source.connect(filter); tone.connect(filter); filter.connect(gain); gain.connect(c.destination);
      this.flight = { source, tone, gain, filter }; source.start(); tone.start();
    }
    unlock() {
      if (!this.enabled) return;
      try {
        const Audio = global.AudioContext || global.webkitAudioContext;
        if (!Audio) return;
        if (!this.context) this.context = new Audio();
        if (this.context.state === 'suspended') this.context.resume().catch(() => {});
      } catch { /* Audio unavailable: the match remains playable. */ }
    }
    hit(slot) {
      const ctx = this.context;
      if (!this.enabled || !ctx || ctx.state !== 'running') return;
      const now = ctx.currentTime;
      if (now - this.last[slot] < .045) return;
      this.last[slot] = now;
      const oscillator = ctx.createOscillator(), gain = ctx.createGain();
      oscillator.type = 'triangle';
      oscillator.frequency.setValueAtTime(slot === 0 ? 330 : 290, now);
      oscillator.frequency.exponentialRampToValueAtTime(100, now + .045);
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(.16, now + .002);
      gain.gain.exponentialRampToValueAtTime(.001, now + .075);
      oscillator.connect(gain); gain.connect(ctx.destination);
      oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
      oscillator.start(now); oscillator.stop(now + .08);
    }
    play(type) {
      const ctx = this.context;
      if (!this.enabled || !ctx || ctx.state !== 'running') return;
      if (type === 'remoteClick') {
        this.tone(700, 220, .045, .09, 'triangle');
      } else if (type === 'missileCharge') {
        this.tone(420, 520, .10, .08, 'sine');
      } else if (type === 'missileLaunch') {
        this.tone(130, 38, .35, .20, 'sine');
        this.tone(1100, 120, .42, .09, 'sawtooth'); this.noise(.45, .20, 'lowpass', 2400);
      } else if (type === 'missileExplosion') {
        this.tone(125, 28, .5, .26, 'sine'); this.noise(.55, .29, 'lowpass', 1500);
      }
    }
    tone(from, to, duration, volume, type) {
      const c = this.context, now = c.currentTime, oscillator = c.createOscillator(), gain = c.createGain();
      oscillator.type = type; oscillator.frequency.setValueAtTime(from, now); oscillator.frequency.exponentialRampToValueAtTime(to, now + duration);
      gain.gain.setValueAtTime(0, now); gain.gain.linearRampToValueAtTime(volume, now + .008); gain.gain.exponentialRampToValueAtTime(.001, now + duration);
      oscillator.connect(gain); gain.connect(c.destination); oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
      oscillator.start(now); oscillator.stop(now + duration);
    }
    noise(duration, volume, type, frequency) {
      const c = this.context, now = c.currentTime, buffer = c.createBuffer(1, Math.ceil(c.sampleRate * duration), c.sampleRate);
      const samples = buffer.getChannelData(0); for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
      const source = c.createBufferSource(), filter = c.createBiquadFilter(), gain = c.createGain(); source.buffer = buffer;
      filter.type = type; filter.frequency.setValueAtTime(frequency, now);
      gain.gain.setValueAtTime(0, now); gain.gain.linearRampToValueAtTime(volume, now + .005); gain.gain.exponentialRampToValueAtTime(.001, now + duration);
      source.connect(filter); filter.connect(gain); gain.connect(c.destination);
      source.onended = () => { source.disconnect(); filter.disconnect(); gain.disconnect(); };
      source.start(now); source.stop(now + duration);
    }
  }
  global.ArenaWallSound = ArenaWallSound;
})(globalThis);
