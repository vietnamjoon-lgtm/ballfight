/* New abilities can contain their own cast, update and draw functions here.
   Save files contain only IDs and numbers, never executable code. */
(function (global) {
  const field = (label, min, max, step, value) => ({ label, min, max, step, default: value });
  global.ArenaAbilities.nose = {
    label: '늘어나는 코',
    description: '발동 순간 상대 방향으로 코를 뻗었다가 회수합니다. 실제 코에 닿아야 적중하며 한 번 뻗을 때 한 번만 피해를 줍니다.',
    fields: {
      damage: field('피해', 1, 100, 1, 24), range: field('최대 길이', 80, 600, 10, 380),
      width: field('코 두께', 8, 60, 1, 24), extend: field('늘어나는 시간 (초)', .1, 1, .05, .25),
      hold: field('유지 시간 (초)', 0, 1, .05, .15), retract: field('돌아오는 시간 (초)', .1, 1, .05, .3)
    },
    cast(api, self, target, p) {
      api.effect('nose', self, { ...p, angle: Math.atan2(target.y - self.y, target.x - self.x), age: 0, length: 0, hit: false }, p.extend + p.hold + p.retract);
    },
    update(e, api, self, target, dt) {
      e.age += dt;
      const ratio = e.age < e.extend ? 1 - Math.pow(1 - e.age / e.extend, 2) : e.age < e.extend + e.hold ? 1 : Math.max(0, 1 - (e.age - e.extend - e.hold) / e.retract);
      const dx = Math.cos(e.angle), dy = Math.sin(e.angle);
      e.x = self.x + dx * self.radius * .55; e.y = self.y + dy * self.radius * .55;
      // Stop at the inside edge of the wall, including the rounded tip.
      const inset = 6 + e.width / 2;
      const bx = Math.abs(dx) < 1e-8 ? Infinity : ((dx > 0 ? 720 - inset : inset) - e.x) / dx;
      const by = Math.abs(dy) < 1e-8 ? Infinity : ((dy > 0 ? 720 - inset : inset) - e.y) / dy;
      e.length = Math.max(0, Math.min(e.range * ratio, bx, by));
      const projection = Math.max(0, Math.min(e.length, (target.x - e.x) * dx + (target.y - e.y) * dy));
      const distance = Math.hypot(target.x - (e.x + dx * projection), target.y - (e.y + dy * projection));
      if (!e.hit && e.age <= e.extend + e.hold && e.length > 0 && distance <= target.radius + e.width / 2) {
        e.hit = true; api.damage(target, e.damage, self); api.pushAway(target, self);
      }
    },
    draw(ctx, e) {
      if (!e.length) return;
      ctx.translate(e.x, e.y); ctx.rotate(e.angle);
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#6c3434'; ctx.lineWidth = e.width + 4;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(e.length, 0); ctx.stroke();
      const skin = ctx.createLinearGradient(0, -e.width / 2, 0, e.width / 2);
      skin.addColorStop(0, '#f6c4b2'); skin.addColorStop(.4, '#df9589'); skin.addColorStop(1, '#aa5558');
      ctx.strokeStyle = skin; ctx.lineWidth = e.width;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(e.length, 0); ctx.stroke();
      ctx.strokeStyle = '#ffe1d1'; ctx.lineWidth = Math.max(2, e.width * .13);
      ctx.beginPath(); ctx.moveTo(3, -e.width * .22); ctx.lineTo(Math.max(3, e.length - 7), -e.width * .22); ctx.stroke();
      ctx.fillStyle = '#73393e';
      for (const y of [-e.width * .17, e.width * .17]) { ctx.beginPath(); ctx.ellipse(e.length - 1, y, 3, 2, 0, 0, Math.PI * 2); ctx.fill(); }
    }
  };
  global.ArenaNosePreset = {
    ability: { id: 'pack_nose_v1', name: '쭉 늘어나는 코', type: 'nose', cooldown: 2.8, params: { damage: 24, range: 380, width: 24, extend: .25, hold: .15, retract: .3 } },
    character: { id: 'pack_nose_demo_v1', name: '코 늘리기', color: '#b198d1', hp: 200, speed: 200, radius: 42, contactDamage: 5, image: '', abilities: ['pack_nose_v1'] }
  };
})(globalThis);
